# 🚀 Quick Start Guide

## Option 1: Easiest (Windows/Mac/Linux)

### Step 1: Install Python
- Go to https://python.org
- Download Python 3.10 or newer
- **IMPORTANT:** Check "Add Python to PATH" during installation

### Step 2: Install Flask
Open terminal/command prompt and type:
```
pip install flask
```

### Step 3: Run the App
**Windows:** Double-click `start.bat`
**Mac/Linux:** Open terminal in folder, type:
```
./start.sh
```

### Step 4: Open in Browser
- Go to: `http://localhost:5000`
- You're in! 🎉

---

## Option 2: Phone Access (Same WiFi)

### Find Your Computer's IP
**Windows:** Open Command Prompt, type `ipconfig`, look for "IPv4 Address"
**Mac:** Open Terminal, type `ifconfig | grep inet`
**Linux:** Open Terminal, type `hostname -I`

### On Your Phone
- Open browser
- Go to: `http://YOUR_IP:5000` (e.g., `http://192.168.1.5:5000`)
- Add to home screen (see README for steps)

---

## First Time Setup

1. Open app in browser
2. You'll see 4 habits pre-loaded
3. "No Smoking" and "Personal Habit" start in Phase 1 (trigger mapping)
4. Tap "Log Trigger" whenever you feel the urge
5. After ~14 triggers, switch to Phase 2
6. Start tracking streaks!

---

## Daily Workflow

```
Morning:     Set energy slider → Plan your day
During day:  Tap ✅ / 🔄 / ❌ / 📝 as things happen
Evening:     Check streaks → Feel good about progress
```

---

## Need Help?

Read the full README.md for:
- Detailed feature explanations
- Customization guide
- Troubleshooting
- Data backup instructions
