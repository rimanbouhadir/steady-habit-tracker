#!/bin/bash
echo "Starting Steady App..."
echo ""
echo "Open your browser and go to: http://localhost:5000"
echo ""
echo "To access from phone, use your computer's IP address"
echo ""
python3 app.py
